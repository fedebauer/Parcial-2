using UnityEngine;

public class ResetGameManager : MonoBehaviour
{
    public void RGameManager()
    {
        GameManager.Instance.Reset();
    }
}
